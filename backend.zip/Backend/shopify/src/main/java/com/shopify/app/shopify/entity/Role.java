package com.shopify.app.shopify.entity;

public enum Role {

	BUYER,
	SELLER
}
